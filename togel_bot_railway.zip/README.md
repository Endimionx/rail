
# 🤖 Bot Telegram Prediksi Togel AI

Bot Telegram untuk memprediksi angka togel 4D menggunakan model AI LSTM.

## 🚀 Cara Deploy ke Railway
1. Buat bot di [@BotFather](https://t.me/botfather), dapatkan `BOT_TOKEN`
2. Fork atau upload folder ini ke GitHub
3. Deploy ke [Railway](https://railway.app)
4. Tambahkan variable BOT_TOKEN di dashboard Railway
5. Bot Anda akan aktif 24 jam

## 🔧 Commands
- `/start` — menyambut pengguna
- `/input 1234,5678,...` — masukkan angka
- `/prediksi` — prediksi angka berikutnya
